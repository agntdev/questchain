"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBot = exports.session = exports.UI = void 0;
exports.UI = {};
exports.session = () => (ctx, next) => next();
exports.createBot = (token, config) => ({ token, config });
