import { Bot, Context } from "grammy";

export interface BotConfig {
  session?: { type: string };
}

export declare function createBot(token: string, config?: BotConfig): Bot<Context>;
export declare function session(): (ctx: Context, next: () => Promise<void>) => Promise<void>;

export declare const UI: Record<string, unknown>;
